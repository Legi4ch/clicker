package ru.fastly.clicker

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

private lateinit var binding: ResultProfileBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}